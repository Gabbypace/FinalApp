//
//  ViewControllerTen.swift
//  FInalProjectApp
//
//  Created by Saige Forbes on 8/1/21.
//

import UIKit

class ViewControllerTen: UIViewController {

    @IBOutlet weak var questionLabelVC10: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func appDevPressed(_ sender: UIButton) {
    }
    
    @IBAction func webDevPressed(_ sender: UIButton) {
    }
    
    
    @IBAction func UIUXPressed(_ sender: UIButton) {
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
